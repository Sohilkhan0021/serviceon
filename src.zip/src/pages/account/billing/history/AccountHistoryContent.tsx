import { Invoicing } from './blocks';

const AccountHistoryContent = () => {
  return (
    <div className="grid gap-5 lg:gap-7.5">
      <Invoicing />
    </div>
  );
};

export { AccountHistoryContent };
